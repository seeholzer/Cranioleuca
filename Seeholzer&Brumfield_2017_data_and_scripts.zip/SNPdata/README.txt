SNPdata.txt
	Contains unphased SNPs for 5154 loci across 175 individuals include three Cranioleuca curtata as outgroups (cra.cur.B43876, cra.cur.B6032, cra.cur.B8175). Columns correspond to locus ID (1 through 5154), the key for the identification of the nucleotides of the SNPs, and the IDs of the 175 individuals included in the dataset. The IDs correspond to the IDs in Data.Table.txt.

STRUCTURE.input.file.txt
	This the SNPdata.txt file converted into the input format for STRUCTURE. Although we did not use STRUCTURE in our analyses, it is a common input file format that can be converted easily to the input formats for the R package Adegenet and for ADMIXTURE.	
	

